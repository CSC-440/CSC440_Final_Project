# Basic Java Spark Framework Demo

Starting with [tutorial](http://prashantb.me/working-with-java-spark-framework/) this has been modded to fit task assigned.
