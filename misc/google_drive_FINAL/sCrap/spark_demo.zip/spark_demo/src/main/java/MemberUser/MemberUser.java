package MemberUser;

public class MemberUser implements Validable{
 

        private String memberName;
        private String memberNumber;
        private String memberStreetAddress;
        private String memberCity;
        private String memberState;
        
        private long memberZipCode;

        public String getMemberName() {
            return memberName;
        }

        public void setMemberName(String memberName) {
            this.memberName = memberName;
        }

        public String getMemberNumber() {
            return memberNumber;
        }

        public void setMemberNumber(String memberNumber) {
            this.memberNumber = memberNumber;
        }

        public String getMemberStreetAddress() {
            return memberStreetAddress;
        }

        public void setMemberStreetAddress(String memberStreetAddress) {
            this.memberStreetAddress = memberStreetAddress;
        }

        public String getMemberCity() {
            return memberCity;
        }

        public void setMemberCity(String memberCity) {
            this.memberCity = memberCity;
        }

        public String getMemberState() {
            return memberState;
        }

        public void setMemberState(String memberState) {
            this.memberState = memberState;
        }

        public long getMemberZipCode() {
            return memberZipCode;
        }

        public void setMemberZipCode(long memberZipCode) {
            this.memberZipCode = memberZipCode;
        }

/*
ToDo : Get the validation straigtened out.

Validation Criteria:

Member name (25 characters).
Member number (9 digits).
Member street address (25 characters).
Member city (14 characters).
Member state (2 letters).
Member ZIP code (5 digits).

*/


    @Override
    public boolean isValid() {
        if(memberName == null || memberNumber == null || memberStreetAddress == null || memberCity == null)
        {
            return false;
        }
        if(memberName.isEmpty() || memberNumber.isEmpty() || memberStreetAddress.isEmpty() || memberCity.isEmpty())
        {
            return false;
        }
        if(memberName.length() > 25 )
        {
            return false;
        }
        if(memberNumber.length() != 9 )
        {
            return false;
        }
        return true;
    }
}
